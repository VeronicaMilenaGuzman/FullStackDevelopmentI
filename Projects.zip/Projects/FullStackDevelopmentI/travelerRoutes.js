const express = require('express');
const router = express.Router();
const travelerController = require('../controllers/travelerController');

// Define the route for the homepage
router.get('/', travelerController.homePage);

// Define the route for the about page
router.get('/about', travelerController.aboutPage);

module.exports = router;
