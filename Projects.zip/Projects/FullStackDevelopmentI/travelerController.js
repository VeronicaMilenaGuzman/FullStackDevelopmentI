// travelerController.js
const path = require('path');

// Render the homepage
exports.homePage = (req, res) => {
    res.render('index', { title: 'Welcome to Travlr', message: 'Explore the World with Us!' });
};

// Render the about page
exports.aboutPage = (req, res) => {
    res.render('about', { title: 'About Us', description: 'We are passionate about travel!' });
};
