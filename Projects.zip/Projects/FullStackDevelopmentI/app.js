// app.js
const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

// app.js

const express = require('express');
const mongoose = require('./db'); // Import the db connection
const app = express();

// Use your routes, models, etc. here

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});

