// Import required modules
const express = require('express');
const exphbs = require('express-handlebars');  // Handlebars templating engine
const travelerRoutes = require('./routes/travelerRoutes');  // Import routes

// Initialize Express app
const app = express();

// Set up Handlebars as the templating engine
app.engine('hbs', exphbs({ extname: 'hbs' }));
app.set('view engine', 'hbs');

// Set up routes (use the routes from travelerRoutes.js)
app.use('/', travelerRoutes);

// Set up the server to listen on port 3000 (or process.env.PORT if provided)
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
