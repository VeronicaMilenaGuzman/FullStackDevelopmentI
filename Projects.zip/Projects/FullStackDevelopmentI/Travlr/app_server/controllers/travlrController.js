const express = require('express');
const router = express.Router();
const tripsData = require('../data/trips.json'); // Data to be rendered dynamically

// Render the home page with data
router.get('/', (req, res) => {
  res.render('home', { trips: tripsData });
});

module.exports = router;
