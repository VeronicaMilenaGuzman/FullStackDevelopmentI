const express = require('express');
const router = express.Router();
const tripModel = require('../models/tripModel');  // Import the model

// Route to render homepage with trips data
router.get('/', (req, res) => {
  const trips = tripModel.getTrips();  // Get trips data from model
  res.render('index', { trips });  // Render the index view with trips data
});

// Route to render trip details
router.get('/trip/:id', (req, res) => {
  const trips = tripModel.getTrips();
  const trip = trips.find(t => t.id === parseInt(req.params.id));  // Find the specific trip
  if (trip) {
    res.render('trip-detail', { trip });  // Render the trip detail view with the specific trip
  } else {
    res.status(404).send('Trip not found');
  }
});

module.exports = router;
