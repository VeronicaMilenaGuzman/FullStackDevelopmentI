const fs = require('fs');
const path = require('path');

// Function to get all trips
const getTrips = () => {
  try {
    const tripsData = fs.readFileSync(path.join(__dirname, '../data/trips.json'), 'utf8');
    return JSON.parse(tripsData);  // Parse the JSON data
  } catch (error) {
    console.error('Error reading trips data:', error);
    return [];
  }
};

module.exports = { getTrips };
