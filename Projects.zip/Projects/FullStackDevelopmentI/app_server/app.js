const express = require('express');
const { engine } = require('express-handlebars');  // Correct import of Handlebars engine
const app = express();
const port = 3000;

// Set Handlebars as the template engine
app.engine('hbs', engine({ extname: 'hbs' }));  // Use `engine` from express-handlebars
app.set('view engine', 'hbs');

// Define a basic route
app.get('/', (req, res) => {
  res.render('home', { message: 'Hello, World!' });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

