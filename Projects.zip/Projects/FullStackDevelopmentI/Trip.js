const mongoose = require('mongoose');

// Define a schema for the trips collection
const tripSchema = new mongoose.Schema({
  destination: {
    type: String,
    required: true,
    minlength: 3
  },
  duration: {
    type: Number,
    required: true
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  description: {
    type: String,
    required: true,
    minlength: 10
  }
});

// Create the model using the schema
const Trip = mongoose.model('Trip', tripSchema);

// Export the model for use in other modules
module.exports = Trip;
