const express = require('express');
const router = express.Router();
const tripController = require('../controllers/tripController');

router.get('/trips', tripController.getTrips); // Get all trips
router.get('/trips/:id', tripController.getTripById); // Get trip by ID

module.exports = router;
