const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const apiRoutes = require('./routes/apiRoutes');
const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://localhost/tripdb', { useNewUrlParser: true, useUnifiedTopology: true });

// Middleware
app.use(bodyParser.json());

// Use routes
app.use('/API', apiRoutes);

// Start server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
