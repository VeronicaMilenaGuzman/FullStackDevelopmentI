const mongoose = require('./db');
const Trip = require('./Trip');

// Sample trip data
const trips = [
  { destination: 'Paris', duration: 7, price: 1500, description: 'Enjoy the beauty of Paris.' },
  { destination: 'New York', duration: 5, price: 1200, description: 'Explore the Big Apple.' },
  { destination: 'Tokyo', duration: 10, price: 2000, description: 'Experience Japanese culture.' }
];

// Insert sample data into the database
Trip.insertMany(trips)
  .then(() => {
    console.log('Database populated with sample trips.');
    mongoose.connection.close();
  })
  .catch(err => {
    console.error('Error inserting data:', err);
  });
