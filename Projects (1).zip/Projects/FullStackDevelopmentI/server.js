// Import required modules
const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Trip = require('./Trip'); // Import the Trip model

// Create an instance of the Express application
const app = express();
const PORT = process.env.PORT || 3000; // Set the port number

// MongoDB connection string (replace with your actual MongoDB URI)
const dbURI = 'mongodb://localhost:27017/travlr'; // or use MongoDB Atlas URI

// Connect to MongoDB using Mongoose
mongoose.connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch(err => {
    console.error('Error connecting to MongoDB:', err);
  });

// Middleware to parse JSON request bodies
app.use(bodyParser.json());

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Define a route to retrieve all trips from the MongoDB database
app.get('/api/trips', (req, res) => {
  Trip.find({})
    .then(trips => res.json(trips))  // Send the retrieved trips data as JSON
    .catch(err => res.status(500).json({ error: err.message }));  // Handle any errors
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
