// db.js

const mongoose = require('mongoose');

// MongoDB connection string
// If you are using MongoDB locally, the URL might be like: 'mongodb://localhost:27017/travlr'
// Replace it with your MongoDB Atlas URL if you're using the cloud.

const mongoDB = 'mongodb://localhost:27017/travlr';  // Local MongoDB
// If you use MongoDB Atlas, replace with the connection string provided in Atlas
// const mongoDB = 'mongodb+srv://<your-atlas-username>:<your-atlas-password>@cluster0.mongodb.net/travlr?retryWrites=true&w=majority';

mongoose.connect(mongoDB, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => {
    console.log('Successfully connected to MongoDB!');
  })
  .catch((error) => {
    console.error('Error connecting to MongoDB:', error.message);
  });

module.exports = mongoose;  // Export mongoose for use in other files (e.g., tripModel.js)

